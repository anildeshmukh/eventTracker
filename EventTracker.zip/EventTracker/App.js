/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import 'react-native-gesture-handler';
import React from 'react';
import { SafeAreaView, ActivityIndicator } from 'react-native';

import { Provider } from 'react-redux';
import Root from './js/Root';
import { PersistGate } from 'redux-persist/lib/integration/react';
import configureStore from './js/store/configureStore';

const { persistor, store } = configureStore()

function App() {
  return (
    <SafeAreaView style={{flex: 1}}>
      <Provider store={store}>
        <PersistGate 
          loading={<ActivityIndicator />} 
          persistor={persistor}>
          <Root />
        </PersistGate>
      </Provider>
    </SafeAreaView>
  );
}

export default App;