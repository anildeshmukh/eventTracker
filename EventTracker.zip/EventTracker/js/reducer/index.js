
import { combineReducers } from 'redux';
import eventTracker from './eventTrackerReducer';

export default combineReducers({
    eventTracker,
});