

export default function eventTrackerReducer(state = [], action) {
    switch (action.type) {
      case 'TRACK_EVENT':
        if (state.indexOf(action.item) === -1) {
          state.push(action.item);
        }
        return [...state];
      case 'REMOVE_TRACKED_EVENT':
        let index = state.indexOf(action.item);
        state.splice(index, 1);
        return [...state];
      default:
        return state;
    }
  }
  