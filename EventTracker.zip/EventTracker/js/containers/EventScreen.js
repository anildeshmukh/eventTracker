import React, { Component } from 'react';
import { TouchableOpacity, FlatList, StyleSheet, View, Text } from 'react-native';
import eventData from '../mock/mockData';
import { ImageComponent } from '../components';

export default class EventScreen extends Component {

  constructor() {
    super();
    this.state = { 
      gridView: true, 
      btnText: 'Show List' 
    }
  }

  changeView = () => {
    this.setState({ gridView: !this.state.gridView }, () => {
      if (this.state.gridView) {
        this.setState({ btnText: 'Show List' });
      }
      else {
        this.setState({ btnText: 'Show Grid' });
      }
    });
  }

  trackView = item => {
    this.props.navigation.push('Tracked Events', {
      trackList: item,
      showTrackEventButton: true,
    });
  };


  itemSelected = item => {
    this.props.navigation.push('Event Details', {
      selectedItem: item,
      showTrackEventButton: true,
    });
  };

  render() {
    return (
      <View style={styles.container} >
         <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row'}}>
              <TouchableOpacity activeOpacity={0.8} style={styles.buttonDesign} onPress={this.changeView}>
                <Text style={styles.buttonText}>{this.state.btnText}</Text>
              </TouchableOpacity>
              <TouchableOpacity activeOpacity={0.8} style={styles.buttonTrackDesign} onPress={this.trackView}>
                <Text style={styles.buttonText}>Tracked</Text>
              </TouchableOpacity>
            </View>
           
            <FlatList keyExtractor={(item) => item.id}
              key={(this.state.gridView) ? 1 : 0}
              numColumns={this.state.gridView ? 2 : 1}
              data={eventData}
              renderItem={({ item }) =>
                <ImageComponent 
                  item={item}
                  itemSelected={this.itemSelected}
                /> 
              } />
          </View> 
      </View>
    );
  }
}

const styles = StyleSheet.create({ 
    container: {
      flex: 1,
    },
    buttonDesign: {
      flex: .8,
      padding: 15,
      backgroundColor: '#e91e63'
    },
    buttonTrackDesign: {
      flex: .2,
      padding: 15,
      backgroundColor: 'grey'
    },
    buttonText: {
      color: 'white',
      textAlign: 'center',
      alignSelf: 'stretch'
    }
  });