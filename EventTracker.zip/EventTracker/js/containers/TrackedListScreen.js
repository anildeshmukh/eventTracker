import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, FlatList, StyleSheet, Text } from 'react-native';
import { ImageComponent, ListView } from '../components/';

const mapStateToProps = state => {    
    return {
      trackList: state.eventTracker,
    };
};

class TrackedListScreen extends Component {
  constructor(props) {
    super(props);
  }

  itemSelected = item => {
    this.props.navigation.navigate('Event Details', {
      selectedItem: item,
      showTrackBtn: false,
    });
  };

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.body}>
        <FlatList
            data={this.props.trackList}
            renderItem={({ item }) =>
              <ImageComponent 
                item={item}
                itemSelected={this.itemSelected}
              /> 
          }/>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  buttonDesign: {
    flex: .8,
    padding: 15,
    backgroundColor: '#e91e63'
  },
  buttonTrackDesign: {
    flex: .2,
    padding: 15,
    backgroundColor: 'grey'
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    alignSelf: 'stretch'
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    alignSelf: 'stretch'
  }
});

export default connect(mapStateToProps)(TrackedListScreen);