import * as React from 'react';
import _ from 'lodash';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { trackEvent, removeTrackedEvent } from '../action';
import { connect } from 'react-redux';

const mapStateToProps = state => {
  console.log('state 1', state);
  
  return {
    trackList: state.eventTracker,
  };
};

class EventDetailScreen extends React.Component {
  constructor(props) {
    super(props);

    this._renderEventContent = this._renderEventContent.bind(this);
  }

  onPress = () => {
    const { route } = this.props;
    const { showTrackEventButton } = route.params;
    if (showTrackEventButton) {
      this.props.dispatch(
        trackEvent({item: route.params.selectedItem}),
      );
    } else {
      this.props.dispatch(
        removeTrackedEvent({item: route.params.selectedItem}),
      );
    }
  };

_renderEventContent(selectedItem) {
    return(
      <View style={styles.contentContainer}>
      <View>
        <Text style={styles.label}>
          {`Event Name: ${selectedItem.eventName}`}
        </Text>
        <Text style={styles.label}>
          {`Venue: ${selectedItem.eventVenue}`}
        </Text>
      </View>
    </View>
    );
}

render() {
  const { selectedItem, showTrackEventButton } = this.props.route.params;
    return (
      <View style={styles.container} >
          <View activeOpacity={0.8} style={styles.buttonDesign}>
              <Text style={styles.buttonText}>{selectedItem.hasEntryFees ? 'Paid Event' : 'Free Event'}</Text>
          </View>
          <Image
            source={{uri: selectedItem.imageUrl}}
            style={styles.imageContainer}
          /> 
          {this._renderEventContent(selectedItem, showTrackEventButton)}
          <TouchableOpacity activeOpacity={0.8} style={styles.buttonDesign} onPress={this.onPress}>
              <Text style={styles.buttonText}>{showTrackEventButton ? 'TRACK' : 'UNTRACK'}</Text>
          </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  imageContainer: {
    flex: 1,
    height: 250,
  },
  contentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    backgroundColor: '#6960EC',
  },
  label: {
    fontSize: 14,
    paddingVertical: 5,
    fontWeight: '500',
    color: 'white',
  },
  container: {
    flex: 1,
  },
  buttonDesign: {
    padding: 15,
    backgroundColor: '#e91e63'
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    alignSelf: 'stretch'
  }
});

export default connect(mapStateToProps)(EventDetailScreen);
