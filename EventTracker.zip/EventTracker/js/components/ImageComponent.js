import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default class ImageComponent extends Component {
    render() {        
        const { item } = this.props;
        return (
          <TouchableOpacity
            style={styles.imageHolder}
            onPress={() => this.props.itemSelected(item)}>
              <Image source={{ uri: item.imageUrl }} style={styles.image} />
              <View style={styles.textViewHolder}>
                <Text numberOfLines={1} style={styles.textOnImage}>
                  {item.eventName}
                </Text>
              </View>
          </TouchableOpacity>
        );
    }
  }

  const styles = StyleSheet.create(
    {
      imageHolder: {
        margin: 5,
        height: 160,
        flex: 1,
        position: 'relative'
      },
      image: {
        height: '100%',
        width: '100%',
        resizeMode: 'cover'
      },
      textViewHolder: {
        position: 'absolute',
        left: 0,
        bottom: 0,
        right: 0,
        backgroundColor: 'rgba(0,0,0,0.75)',
        paddingHorizontal: 10,
        paddingVertical: 13,
        alignItems: 'center'
      },
      textOnImage: {
        color: 'white'
      },
    });