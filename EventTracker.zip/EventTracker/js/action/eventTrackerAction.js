
export const trackEvent = ({item}) => {
    return {
      type: 'TRACK_EVENT',
      item: item,
    };
  };
  
  export const removeTrackedEvent = ({item}) => {
    return {
      type: 'REMOVE_TRACKED_EVENT',
      item: item,
    };
  };
  