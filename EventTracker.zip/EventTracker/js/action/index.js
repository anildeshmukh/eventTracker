import { trackEvent, removeTrackedEvent } from './eventTrackerAction';

export {
    trackEvent,
    removeTrackedEvent
}