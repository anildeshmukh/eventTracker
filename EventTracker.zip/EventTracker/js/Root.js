import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { EventScreen, EventDetailScreen, TrackedListScreen } from './containers';

const Stack = createStackNavigator();

function Root() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerTintColor: 'white',
          headerStyle: { backgroundColor: '#3090C7', height: 40 },
        }}
      >
        <Stack.Screen name="Event Tracker" component={EventScreen} />
        <Stack.Screen name="Event Details" component={EventDetailScreen} />
        <Stack.Screen name="Tracked Events" component={TrackedListScreen} />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
}
 
export default Root;